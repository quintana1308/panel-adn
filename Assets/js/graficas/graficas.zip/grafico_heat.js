const ElementPricipalHeat = document.getElementById('graficaPricipalHeat');

if (ElementPricipalHeat && ElementPricipalHeat.getAttribute('data-value')) {

    const graficaPricipalHeat = JSON.parse(ElementPricipalHeat.getAttribute('data-value'));

    function getPointCategoryName(point, dimension) {
        const series = point.series,
            isY = dimension === 'y',
            axis = series[isY ? 'yAxis' : 'xAxis'];
        return axis.categories[point[isY ? 'y' : 'x']];
    }

    // Extraer categorías X e Y
    const xCategories = graficaPricipalHeat.PARAM3.map(item => item.MES); // Extraer categorías X
    const yCategories = graficaPricipalHeat.PARAM4.map(item => item.SCS); // Extraer categorías Y

    // Transformar los datos para el gráfico
    const data = [];
    graficaPricipalHeat.PARAM5.forEach((item, index) => {
        // Aquí asumimos que los datos están organizados en un formato específico.
        // La posición en X es la posición en el array
        // La posición en Y se calcula según el número de categorías Y disponibles
        const x = index % xCategories.length;
        const y = Math.floor(index / xCategories.length);
        if (y < yCategories.length) { // Verifica que el índice Y esté dentro de los límites
            data.push([x, y, parseFloat(item.MES1)]);
        }
    });

    Highcharts.chart('graficaPricipalHeat_id', {
        chart: {
            type: 'heatmap',
            marginTop: 40,
            marginBottom: 80,
            plotBorderWidth: 1
        },
        
        title: {
            text: graficaPricipalHeat.DESCRIPTION
        },
        
        xAxis: {
            categories: xCategories
        },
        
        yAxis: {
            categories: yCategories,
            title: null,
            reversed: true
        },
        
        accessibility: {
            point: {
                descriptionFormatter: function(point) {
                    const ix = point.index + 1,
                        xName = getPointCategoryName(point, 'x'),
                        yName = getPointCategoryName(point, 'y'),
                        val = point.value;
                    return ix + '. ' + xName + ' sales ' + yName + ', ' + val + '.';
                }
            }
        },
        
        colorAxis: {
            min: 0,
            minColor: '#FFFFFF',
            maxColor: Highcharts.getOptions().colors[0]
        },
        
        legend: {
            align: 'right',
            layout: 'vertical',
            margin: 0,
            verticalAlign: 'top',
            y: 25,
            symbolHeight: 280
        },
        
        tooltip: {
            formatter: function() {
                return '<b>' + getPointCategoryName(this.point, 'x') + '</b> mes <br><b>' +
                    this.point.value + '</b> gasto en  <br><b>' + getPointCategoryName(this.point, 'y') +
                    '</b>';
            }
        },
        
        series: [{
            name: 'Sales per employee',
            borderWidth: 1,
            data: data,
            dataLabels: {
                enabled: true,
                color: '#000000'
            }
        }],
        
        responsive: {
            rules: [{
                condition: {
                    maxWidth: 500
                },
                chartOptions: {
                    yAxis: {
                        labels: {
                            formatter: function() {
                                return this.value.charAt(0);
                            }
                        }
                    }
                }
            }]
        }
    });

}