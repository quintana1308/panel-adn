const ElementPricipalDonut = document.getElementById('graficaPricipalDonut');

if (ElementPricipalDonut && ElementPricipalDonut.getAttribute('data-value')) {

    const graficaPricipalDonut = JSON.parse(ElementPricipalDonut.getAttribute('data-value'));
    const idgrafDonut = document.getElementById('graficaPricipalDonut').getAttribute('data-id');

    Highcharts.chart('graficaPricipalDonut_id', {
        chart: {
            type: 'pie',
            options3d: {
                enabled: true,
                alpha: 45
            }
        },
        title: {
            text: graficaPricipalDonut.DESCRIPTION
        },
        subtitle: {
            text: graficaPricipalDonut.PARAM2
        },
        plotOptions: {
            pie: {
                innerSize: 100,
                depth: 45
            }
        },
        series: [{
            name: '',
            data: graficaPricipalDonut.PARAM3.map((item, index) => {
                const name = Object.values(item)[0];
                const value = parseFloat(Object.values(graficaPricipalDonut.PARAM4[index])[0]);
                return {
                    name: name,
                    y: value
                };
            })
        }]
    });

}